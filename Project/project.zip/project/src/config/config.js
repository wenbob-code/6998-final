export default {
    domainPath: 'http://52.130.80.160:8087',  //  开发环境域名
    // domainPath: 'http://192.168.0.38:8087',  // 开发环境域名
    // domainPath: 'http://localhost:8087',  // 本地开发环境
    // domainPath: 'http://139.217.228.165:8087/'
};
