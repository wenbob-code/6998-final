import Vue from 'vue'
import Router from 'vue-router'
import index from '@/pages/index/index' // 首页
import user from '@/pages/user/user' // 个人中心入口页面

// 引入项目依赖组件
import { Icon, Button, Toast, Tab, Tabs, Swipe, SwipeItem, Checkbox, CheckboxGroup, Uploader, Stepper, Dialog, CountDown } from "vant";
Vue.use(Icon).use(Button).use(Toast).use(Tab).use(Tabs).use(Swipe).use(SwipeItem).use(Checkbox).use(CheckboxGroup).use(Uploader).use(Stepper).use(Dialog).use(CountDown)

Vue.use(Router);

Toast.setDefaultOptions({
    duration: 1000,
});

// 解决路由重复打印问题
const originalPush = Router.prototype.push
Router.prototype.push = function push(location, onResolve, onReject) {
    if (onResolve || onReject) return originalPush.call(this, location, onResolve, onReject)
    return originalPush.call(this, location).catch(err => err)
}

export default new Router({
    routes: [
        // 路由重定向
        {
            path: "/",
            component: index,
            redirect: {
                name: "index"
            }
        },
        {
            path: "/index",
            name: "index",
            component: index,
        },
        {
            path: '/user/user',
            name: "user",
            component: user
        }
    ]
});