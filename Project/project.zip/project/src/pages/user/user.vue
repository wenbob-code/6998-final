<template>
  <div class="container">
    个人中心
  </div>
</template>
<script>
export default {
  name: 'user',
  components: {},

  data() {
    return{}
  },

  methods: {},

  mounted() {
    
  },
}
</script>

<style lang="scss" scoped>
</style>

