<template>
  <div class="container">
    <!-- 顶部banner -->
    <div class="topBanner">
      <img src="../../../static/images/banner.jpg" class="banner" />
      <div class="mask">
      <p>CoStudier</p> 
      <p class="font20">-- Your cloud study room</p>
      </div>
    </div>
    <!-- 用户操作栏 -->
    <div class="userOperate">
      <div class="right">
        <div class="btns">
          <!-- 登录按钮 -->
          <el-button type="text" class="mr10">Sign In</el-button>
          <!-- 签出按钮 -->
          <el-button type="text">LogOut</el-button>
        </div>
        <!-- 用户头像 -->
        <div class="userImg" @click="goPersonalCenter">
          <img
            src="../../../static/images/userImg.png"
            v-if="userImg && userImg != ''"
          />
          <img src="../../../static/images/userImg.png" v-else />
        </div>
      </div>
    </div>
    <!-- 顶部导航栏 -->
    <el-tabs v-model="activeName">
      <el-tab-pane label="COMS 4111" name="first"></el-tab-pane>
      <el-tab-pane label="COMS 6998" name="second"></el-tab-pane>
      <el-tab-pane label="ELEN 6767" name="third"></el-tab-pane>
      <el-tab-pane label="ELEN 6883" name="fourth"></el-tab-pane>
    </el-tabs>
    <!-- 内容 -->
    <div class="content">
      <!-- 左侧内容栏 -->
      <div class="leftContent mr20">
        <!-- group -->
        <div class="group pdb30">
          <div class="title mb20">Group</div>
          <div class="groupList">
            <div
              class="group-item"
              v-for="(item, index) in groupList"
              :key="index"
              @click="showGroupDialog"
            >
              <img
                :src="item.groupImg"
                class="groupImg"
                v-if="item.groupImg && item.groupImg != ''"
              />
              <img
                src="../../../static/images/userImg.png"
                class="groupImg"
                v-else
              />
              <p class="groupName">{{ item.groupName }}</p>
            </div>
          </div>
        </div>
        <!-- buddy -->
        <div class="group mb30">
          <div class="title mb20">Buddy</div>
          <div class="groupList">
            <div
              class="group-item"
              v-for="(item, index) in buddyList"
              :key="index"
              @click="showBuddyDialog(index)"
            >
              <img :src="item.buddyImg" class="groupImg" />
              <p class="groupName">{{ item.buddyName }}</p>
            </div>
          </div>
        </div>
      </div>
      <!-- 右侧内容栏 -->
      <div class="rightContent">
        <!-- 日历 -->
        <div class="calendar">
          <functional-calendar
            v-model="calendarData"
            :markedDates="markedDates"
            :dayNames="['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU']"
            :markedDateRange="markedDateRange"
            :sundayStart="true"
            @changedMonth="toggleMonth"
            :isDateRange="false"
            :markedDatesColor="markedDatesColor"
          ></functional-calendar>
        </div>
        <!-- meeting -->
        <div class="meeting">
          <p class="colorfff font20 mb20">Meeting</p>
          <div class="meetingList">
            <div
              v-for="(item, index) in meetingList"
              :key="index"
              class="meeting-item mb20"
            >
              <div class="icon mr10"></div>
              <div class="colorfff">
                <p>{{ item.meetingTime }}</p>
                <p>{{ item.meetingName }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- groupDialog -->
    <el-dialog :visible.sync="groupDialogFlag" class="groupDialog" width="25%">
      <img :src="groupQrCode" class="groupQrCode" />
    </el-dialog>
    <!-- buddyDialog -->
    <el-dialog :visible.sync="buddyDialogFlag" class="buddyDialog">
      <!-- basicinfo -->
      <div class="basicInfo mb20">
        <img src="../../../static/images/peter.jpg" class="buddyImg mr20" />
        <div class="info font20 lh25">
          <p>Huiyu Zhao</p>
          <p>Electrical Engineering (2nd semester)</p>
          <p>Email: hz2691@columbia.edu</p>
        </div>
      </div>
      <!-- course-learning-info -->
      <div class="courseLearning-info">
        <p class="font20 title mb10">Course Learned:</p>
        <p class="lh25 pdl5">CSEE 4119 W COMPUTER NETWORKS</p>
        <p class="lh25 pdl5">EECS 4764 E IoT - INTELLIG & CONNECTE</p>
        <p class="lh25 pdl5">EEOR 4650 E CONVEX OPTIMIZATION ELCT</p>
        <p class="lh25 pdl5">ELEN 6761 E COMPUTER COMMUNCATION NET</p>
      </div>
    </el-dialog>
    <!-- jwbDialog -->
    <el-dialog :visible.sync="jwbDialogFlag" class="buddyDialog">
      <!-- basicinfo -->
      <div class="basicInfo mb20">
        <img src="../../../static/images/jwb.jpg" class="buddyImg mr20" />
        <div class="info font20 lh25">
          <p>Wenbo Jiang</p>
          <p>Computer Engineering (2nd semester)</p>
          <p>Email: wj2311@columbia.edu</p>
        </div>
      </div>
      <!-- course-learning-info -->
      <div class="courseLearning-info">
        <p class="font20 title mb10">Course Learned:</p>
        <p class="lh25 pdl5">COMS 4111 W INTRODUCTION TO DATABASES</p>
        <p class="lh25 pdl5">EECS 4764 E IoT - INTELLIG & CONNECTE</p>
        <p class="lh25 pdl5">CSEE 4119 W COMPUTER NETWORKS</p>
        <p class="lh25 pdl5">CSEE 4868 W System-On-Chip Platforms</p>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { FunctionalCalendar } from "vue-functional-calendar";
export default {
  name: "index",
  components: {
    FunctionalCalendar,
  },

  data() {
    return {
      activeName: "first", // 导航栏下标
      userImg: "", // 用户头像
      calendarData: {},
      markedDates: [],
      markedDatesColor: {},
      markedDateRange: [],
      meetingList: [
        {
          meetingTime: "2021/2/15 10:00",
          meetingName: "international academic conferences",
        },
        {
          meetingTime: "2021/2/15 10:00",
          meetingName: "international academic conferences",
        },
        {
          meetingTime: "2021/2/15 10:00",
          meetingName: "international academic conferences",
        },
      ],
      // groupList: [
      //   {
      //     groupImg:
      //       "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3505972091,655450644&fm=26&gp=0.jpg",
      //     groupName: "groupMe",
      //   },
      //   {
      //     groupImg:
      //       "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2043718202,425822973&fm=26&gp=0.jpg",
      //     groupName: "faceBook",
      //   },
      //   {
      //     groupImg:
      //       "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1118145297,860305148&fm=26&gp=0.jpg",
      //     groupName: "wechat",
      //   },
      // ],
      // buddyList: [
      //   {
      //     buddyImg: require("../../../static/images/peter.jpg"),
      //     buddyName: "Huiyu Zhao",
      //   },
      //   {
      //     buddyImg: require("../../../static/images/jwb.jpg"),
      //     buddyName: "Wenbo Jiang",
      //   },
      // ],
      groupDialogFlag: false,
      groupQrCode: require("../../../static/images/qrCodeOne.png"),
      buddyDialogFlag: false,
      jwbDialogFlag: false,
    };
  },

  methods: {
    //  跳转个人中心
    goPersonalCenter(){
      this.$router.push('/user/user')
    },
    //  日历切换月份
    toggleMonth(date) {
      console.log(date);
    },
    //  展示group二维码
    showGroupDialog() {
      this.groupDialogFlag = true;
    },
    //  展示buddy信息弹窗
    showBuddyDialog(index) {
      if (index == 0) {
        this.buddyDialogFlag = true;
      } else if (index == 1) {
        this.jwbDialogFlag = true;
      }
    },
  },

  mounted() {},
  computed: {
    groupList: function () {
      let arr;
      if (this.activeName== "first") {
        arr = [
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3505972091,655450644&fm=26&gp=0.jpg",
            groupName: "groupMe",
          },
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2043718202,425822973&fm=26&gp=0.jpg",
            groupName: "faceBook",
          },
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1118145297,860305148&fm=26&gp=0.jpg",
            groupName: "wechat",
          },
        ];
      } else if (this.activeName== "second") {
        arr = [
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3505972091,655450644&fm=26&gp=0.jpg",
            groupName: "groupMe",
          },
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2043718202,425822973&fm=26&gp=0.jpg",
            groupName: "faceBook",
          },
        ];
      } else if (this.activeName== "third") {
        arr = [
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3505972091,655450644&fm=26&gp=0.jpg",
            groupName: "groupMe",
          },
        ];
      } else if (this.activeName== "fourth") {
        arr = [
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3505972091,655450644&fm=26&gp=0.jpg",
            groupName: "groupMe",
          },
          {
            groupImg:
              "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1118145297,860305148&fm=26&gp=0.jpg",
            groupName: "wechat",
          },
        ];
      }
      return arr;
    },
    buddyList: function () {
      let arr;
      if (this.activeName== "first") {
        arr =  [
        {
          buddyImg: require("../../../static/images/peter.jpg"),
          buddyName: "Huiyu Zhao",
        },
        {
          buddyImg: require("../../../static/images/jwb.jpg"),
          buddyName: "Wenbo Jiang",
        },
      ]
      } else if (this.activeName== "second") {
        arr = [
        {
          buddyImg: require("../../../static/images/peter.jpg"),
          buddyName: "Huiyu Zhao",
        },
      ]
      } else if (this.activeName== "third") {
        arr = [
        {
          buddyImg: require("../../../static/images/jwb.jpg"),
          buddyName: "Wenbo Jiang",
        },
      ]
      } else if (this.activeName== "fourth") {
        arr = [
        {
          buddyImg: require("../../../static/images/peter.jpg"),
          buddyName: "Huiyu Zhao",
        },
      ]
      }
      return arr;
    },
  },
};
</script>

<style lang="scss" scoped>
.container {
  padding-bottom: 50px;
  background-color: #acc8ec;
  .topBanner {
    width: 100%;
    height: 500px;
    position: relative;
    .banner {
      width: 100%;
      height: 100%;
    }
    .mask{
      position: absolute;
      width: 350px;
      padding: 40px 0;
      background-color: rgba($color: #000000, $alpha: 0.7);
      color: #fff;
      font-size: 60px;
      text-align: center;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
      border-radius: 10px;
    }
  }
  .userOperate {
    width: 100%;
    height: 50px;
    display: flex;
    justify-content: flex-end;

    background-color: lightgrey;
    .right {
      width: 20%;
      height: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      .userImg {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        cursor: pointer;
        img {
          width: 100%;
          height: 100%;
          border-radius: 50%;
        }
      }
    }
  }
  .el-menu-demo {
    padding: 0 20px;
  }
  .content {
    display: flex;
    padding: 0 20px;
    .leftContent {
      width: 80%;
      height: 500px;
      // background-color: red;
      .group {
        background-color: #acc8ec;
        .groupList {
          display: flex;
          .group-item {
            width: 120px;
            flex-basis: 15%;
            cursor: pointer;
            .groupImg {
              display: block;
              width: 100px;
              height: 100px;
              border-radius: 50%;
              margin: 0 auto 10px;
            }
            .groupName {
              width: 100%;
              text-align: center;
              font-size: 20px;
              color: #fff;
            }
          }
        }
      }
    }
    .rightContent {
      width: 20%;
      // height: 500px;
      padding-bottom: 50px;
      background-color: #3767a6;
      .meeting {
        padding: 0 20px;
        .meetingList {
          height: 500px;
          .meeting-item {
            padding: 10px 15px;
            background-color: #3f77bf;
            display: flex;
            align-items: center;
            .icon {
              flex-shrink: 0;
              width: 15px;
              height: 15px;
              border: 2px solid #5eb88c;
              border-radius: 50%;
            }
          }
        }
      }
    }
  }
  .groupQrCode {
    display: block;
    width: 350px;
    height: 350px;
  }
  .basicInfo {
    display: flex;
    align-items: center;
  }
  .buddyImg {
    display: block;
    width: 100px;
    height: 100px;
    border-radius: 50%;
  }
  .title {
    padding: 10px;
    background-color: #3767a6;
    color: #fff;
    font-weight: 700;
    font-size: 20px;
    display: flex;
    align-items: center;
  }
}
/deep/ .el-menu--horizontal > .el-menu-item.is-active {
  border-bottom: 3px solid #409eff;
}
.calendar {
  // height: 610px;
  /deep/ .vc-container {
    background: #3767a6;
    color: #fff;
    .vc-title {
      color: #fff;
    }
    .vc-text-gray-600 {
      color: #fff;
    }
    .vc-weeks {
      color: #fff;
    }
    .vc-arrows-container {
      justify-content: space-around;
    }
    .vc-text-gray-500 {
      color: #fff;
    }
    .vc-header {
      padding: 25px 0;
      border-bottom: 1px solid #fff;
      margin-bottom: 30px;
    }
    .vc-arrows-container {
      padding: 25px 0;
    }
    .vc-grid-cell {
      margin-bottom: 20px;
    }
  }
  /deep/ .vc-border-gray-400 {
    border-color: #3767a6;
  }
}
/deep/ .vfc-calendars-container {
  background-color: #3767a6;
}
/deep/ .vfc-dayNames span {
  width: 100%;
  margin-right: 0.025rem;
  color: #ffffff;
  text-align: center;
  // font-size: 20px;
}

/deep/ .vfc-week .vfc-day span.vfc-span-day {
  display: inline-block;
  text-align: center;
  // width: 0.15rem;
  // line-height: 0.15rem;
  border-radius: 50%;
  margin: 0 auto;
  vertical-align: middle;
  // font-size: 20px;
  color: #fff;
}
/deep/ .vfc-dayNames {
  -webkit-box-flex: 0.15rem;
  -ms-flex: 0.15rem 0 0;
  flex: 0.15rem 0 0;
  margin-bottom: 0.05rem;
  // width: 27px;
  height: 25px;
  font-size: 16px;
  font-family: PingFangSC-Medium, PingFang SC;
  // font-weight: 500;
  color: #ffffff;
  line-height: 25px;
}
/deep/ .vfc-top-date {
  font-family: PingFangSC-Medium, PingFang SC !important;
}
/deep/ .vfc-main-container {
  box-shadow: none;
}
/deep/ .vfc-top-date {
  span {
    color: #fff;
  }
}
/deep/ .vfc-dayNames {
  span {
    color: #fff;
  }
}
/deep/ .vfc-arrow-left {
  border-color: #fff !important;
}
/deep/ .vfc-arrow-right {
  border-color: #fff !important;
}
/deep/ .vfc-week .vfc-day:last-child {
  color: #fff;
}
/deep/ .vfc-week .vfc-day span.vfc-span-day.vfc-hide {
  color: #bfbfbf;
}
/deep/ .el-tabs__nav-wrap::after{
  background-color: transparent;
}
/deep/ .el-tabs__item.is-active{
  color: #3767a6;
}
/deep/ .el-tabs__active-bar{
  background-color: #3767a6;
}
/deep/ .el-tabs--top .el-tabs__item.is-top:nth-child(2){
  padding-left: 40px;
}
/deep/ .el-tabs__item{
  padding: 0 40px;
  font-size: 20px;
  color: #fff;
}
/deep/ .el-tabs__header{
  padding: 10px 0;
}
.mr10 {
  margin-right: 10px;
}
.mb20 {
  margin-bottom: 20px;
}
.mb30 {
  margin-bottom: 30px;
}
.colorfff {
  color: #fff;
}
.font20 {
  font-size: 20px;
}
.pdb30 {
  padding-bottom: 30px;
}
.lh25 {
  line-height: 25px;
}
.pdl5 {
  padding-left: 5px;
}
</style>
